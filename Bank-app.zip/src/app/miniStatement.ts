export class miniStatement{
    trans_id: string;
    from_acc:string;
    to_acc:string;
    amnt:string;
    date:string;
  success!: miniStatement[];

    constructor(trans_id: string, from_acc: string, to_acc: string, amnt: string, date: string){
        this.trans_id=trans_id;
        this.from_acc=from_acc;
        this.to_acc=to_acc;
        this.amnt=amnt;
        this.date=date;
    }
     
}
