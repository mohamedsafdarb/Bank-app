import { RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { LoginComponent } from './components/auth/login/login.component';
import { AccountVerificationComponent } from './components/auth/account-verification/account-verification.component';
import { BalanceEnquiryComponent } from './components/bank/balance-enquiry/balance-enquiry.component';
import { MainLayoutComponent } from './components/main-layout/main-layout.component';
import { HomeComponent } from './components/bank/home/home.component';
import { MiniStatementComponent } from './components/bank/mini-statement/mini-statement.component';
import { FundTransferComponent } from './components/bank/fund-transfer/fund-transfer.component';

@NgModule({
  declarations: [],
  imports: [
    RouterModule.forRoot([
      { path: 'login', component: LoginComponent },
      { path: 'verify-account', component: AccountVerificationComponent },
      {
        path: 'bank',
        component: MainLayoutComponent,
        children: [
          { path: '', redirectTo: 'home', pathMatch: 'full' },
          { path: 'home', component: HomeComponent },
          { path: 'balance-enquiry', component: BalanceEnquiryComponent },
          { path: 'mini-statement', component: MiniStatementComponent },
          { path: 'fund-transfer', component: FundTransferComponent},
        ],
      },
      { path: '**', redirectTo: 'login' },
    ]),
  ],
  exports: [RouterModule],
  providers: [],
})
export class AppRoutingModule {}
