import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { RestService } from 'src/app/rest.service';

@Component({
  selector: 'app-account-verification',
  templateUrl: './account-verification.component.html',
  styleUrls: ['./account-verification.component.css']
})
export class AccountVerificationComponent implements OnInit {

  loginForm = this.formBuilder.group({ userAcc: ''});
  submitted: boolean = false;
  userAcc: any;
  error: any;
  errorMsg: any;

  constructor(private rest : RestService,
    private formBuilder: FormBuilder,
    private router: Router,) { }

  ngOnInit() {
  }
  onSubmit(): void {
    this.submitted = true;
    //alert("OnSubmit");
   if (this.loginForm.invalid) {
      return;
    }
    //alert(this.loginForm.controls['username'].value);
    //alert(this.loginForm.controls['password'].value);
    this.userAcc = this.loginForm.controls['userAcc'].value;
    this.rest.AccountValidation(this.userAcc).subscribe(response => { 
      console.log(response);
      this.router.navigateByUrl('/bank/home');
    },
    error => {alert("Invalid Credentials"), location.reload()  });
    //this.rest.showHelloWorld().subscribe(response => { console.log('Balance'); console.log(response); 
   // console.log(response.hello)});
    
  }

}
