import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { RestService } from 'src/app/rest.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  //loginForm: any;
  loginForm = this.formBuilder.group({ username: '', password: '' });
  submitted: boolean = false;
  error: any;
  errorMsg: any;


  constructor(private rest : RestService,
      private formBuilder: FormBuilder,
      private router: Router,) { }

  userId: any = '';
  userPass: any = '';

  ngOnInit() {
   /* this.rest.LoginValidation().subscribe(response => {  
   this.userId=response.userId;
   this.userPass=response.userPass;});*/
  }

  onSubmit(): void {
    this.submitted = true;
    //alert("OnSubmit");
   if (this.loginForm.invalid) {
      return;
    }
    //alert(this.loginForm.controls['username'].value);
    //alert(this.loginForm.controls['password'].value);
    this.userId = this.loginForm.controls['username'].value;
    this.userPass = this.loginForm.controls['password'].value;
    this.rest.LoginValidation(this.userId, this.userPass).subscribe(response => { 
      console.log(response)
      if(response.msg === 'Successful'){

        this.router.navigateByUrl('/verify-account');
      } 
    },
    error => {alert("Invalid Credentials"),location.reload() });
    //this.rest.showHelloWorld().subscribe(response => { console.log('Balance'); console.log(response); 
   // console.log(response.hello)});
    
  }

 /* get f() {
    return this.loginForm.controls;
  }*/
}
