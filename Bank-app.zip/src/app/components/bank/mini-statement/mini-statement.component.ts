import { Component, OnInit } from '@angular/core';
import { miniStatement } from 'src/app/miniStatement';
import { RestService } from 'src/app/rest.service';

@Component({
  selector: 'app-mini-statement',
  templateUrl: './mini-statement.component.html',
  styleUrls: ['./mini-statement.component.css']
})
export class MiniStatementComponent implements OnInit {

  constructor(private rest : RestService) { }
  
  headers = ["Transaction Id","From Account", "To Account",  "Amount", "Date"]

  miniStatement : miniStatement[] = [];
  
  ngOnInit()
  {
        this.rest.miniStatement(this.rest.accNum).subscribe((response) => {
          this.miniStatement = response.success;},
          (error) =>{console.log("No Data Found" + error);})
  }
  

}
