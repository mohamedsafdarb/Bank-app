import { HttpClient } from '@angular/common/http';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { RestService } from 'src/app/rest.service';

@Component({
  selector: 'app-balance-enquiry',
  templateUrl: './balance-enquiry.component.html',
  styleUrls: ['./balance-enquiry.component.css']
})
export class BalanceEnquiryComponent implements OnInit {
  [x: string]: any;
  userAcc: any;

  loginForm = this.formBuilder.group({ userAcc: ''});
  

  constructor(private rest : RestService,
    private formBuilder: FormBuilder,) { }

  value: any = '';
  value1: any = '';

  ngOnInit() {
  // alert(this.rest.accNum);
   this.rest.balanceEnquiry(this.rest.accNum).subscribe(response => {  console.log(response); 
   console.log(response.BALANCE);
   this.value=response.BALANCE;});
   this.rest.balanceEnquiry(this.rest.accNum).subscribe(response => {  console.log(response); 
   console.log(response.EFFECTIVE_BALANCE);
   this.value1=response.EFFECTIVE_BALANCE;});  
   
  }

}
