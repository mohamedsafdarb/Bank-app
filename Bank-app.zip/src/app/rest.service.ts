import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { miniStatement } from './miniStatement';


@Injectable({
  providedIn: 'root'
})
export class RestService {

 // private endPointUrl1 =  "http://127.0.0.1:5000/UserLogin";
  private endPointUri = "http://127.0.0.1:5000"
  private balanceDetailsUri =  this.endPointUri + "/BalanceDetails";
  private userValidationUri = this.endPointUri + "/UserLogin";
  private accValidationUri = this.endPointUri + "/AccountValidation";
  private balaneEnquiryUri = this.endPointUri + "/BalanceEnquiry";
  private miniStatementUri = this.endPointUri + "/MiniStatment";
  private fundTransferUri = this.endPointUri + "/FundTransfer";

  public accNum = '';

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }  
  
  constructor(private httpClint : HttpClient) { }

 LoginValidation(userId:string, userPass:string){
    let params = new HttpParams();
    params = params.append("userId", userId);
    params = params.append("userPass", userPass);
    console.log("LoginAvliddation");
    console.log(this.userValidationUri);
    console.log(userId);
    console.log(userPass);
    return this.httpClint.get<any>(this.userValidationUri, { params : params}  );
  }
  AccountValidation(userAcc:string){
    let params = new HttpParams();
    params = params.append("userAcc", userAcc);
    console.log("AccValiddation");
    console.log(this.accValidationUri);
    console.log(userAcc);
    this.accNum=userAcc;
    return this.httpClint.get<any>(this.accValidationUri, { params : params}  );

  }
  
  balanceEnquiry(userAcc:string){
    let params = new HttpParams();
    params = params.append("userAcc", userAcc);
    return this.httpClint.get<any>(this.balaneEnquiryUri, { params : params});
  }
  fundTransfer(){

  }
  miniStatement(userAcc:string){
    let params = new HttpParams();
    params = params.append("userAcc", userAcc);
    return this.httpClint.get<miniStatement>(this.miniStatementUri, { params : params});
  }

  showHelloWorld(){
    /*alert("HAi");
    alert(this.endPointUrl);
    return this.httpClint.get(this.endPointUrl).
      toPromise().then(response => { console.log('SUccess');
                             console.log(response.toString()) } ); */
    return this.httpClint.get<any>(this.balanceDetailsUri);
   /*return this.httpClint.get<any>(this.endPointUrl).subscribe(response => { console.log(response);
      //console.log(response.hello);
      //return response.hello;
   });*/
    //.do(response => console.log('Success'),
    //error => console.log('error'));

  }
}


