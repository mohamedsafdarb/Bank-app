import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app.routing';
import { AccountVerificationComponent } from './components/auth/account-verification/account-verification.component';
import { LoginComponent } from './components/auth/login/login.component';
import { BalanceEnquiryComponent } from './components/bank/balance-enquiry/balance-enquiry.component';
import { HomeComponent } from './components/bank/home/home.component';
import { MainLayoutComponent } from './components/main-layout/main-layout.component';
import { HeaderComponent } from './shared/header/header.component';
import { FundTransferComponent } from './components/bank/fund-transfer/fund-transfer.component';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    LoginComponent,
    HomeComponent,
    HomeComponent,
    AccountVerificationComponent,
    MainLayoutComponent,
    BalanceEnquiryComponent,
    FundTransferComponent
  ],
  imports: [
    AppRoutingModule,
    BrowserModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
